﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LYC.StdMgt.BusinessService.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
