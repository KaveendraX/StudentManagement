﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H2C.Student.Common.Setting
{
    public class AppSettingsLive : IAppSettings
    {
        public string DbConnectionName
        {
            get
            {
                throw new NotImplementedException();
            }

            //set
            //{
            //    throw new NotImplementedException();
            //}
        }

        public int SessionTimeOut
        {
            get
            {
                throw new NotImplementedException();
            }
        }
    }
}
