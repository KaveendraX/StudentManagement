﻿using H2C.Student.Common.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H2C.Student.Repository.Contracts
{
    public interface IStudentRepository : IRepository<Studnt>
    {

    }
}
